import os
import time
import subprocess
import signal
import logging

# --- Konfigurasi ---
TRIGGER_START = "/home/container/ai-pxnda/start_trigger.txt"
TRIGGER_STOP = "/home/container/ai-pxnda/stop_trigger.txt"
SCRIPT_COMMAND = ["python3", "/home/container/ai-pxnda/main.py"]
CHECK_INTERVAL = 5  # detik
LOG_FILE = "/home/container/ai-pxnda/script_log.txt"  # File log untuk mencatat output

# --- Variabel global ---
process = None

# --- Setup Logging ---
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

def log_output(output):
    """Fungsi untuk mencatat output ke file log."""
    logging.info(output)

def start_script():
    global process
    if process is None or process.poll() is not None:
        log_output("Menjalankan script...")
        print("Menjalankan script...")
        
        # Menjalankan script dengan menangkap stdout dan stderr
        process = subprocess.Popen(
            SCRIPT_COMMAND,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Membaca output dari stdout dan stderr
        def read_output(stream, log_func):
            for line in iter(stream.readline, ''):
                if line:
                    log_func(line.strip())
                    print(line.strip())  # Tampilkan juga di console VSCode

        # Mulai membaca output
        from threading import Thread
        Thread(target=read_output, args=(process.stdout, log_output)).start()
        Thread(target=read_output, args=(process.stderr, log_output)).start()
        
    else:
        log_output("Script sudah berjalan.")
        print("Script sudah berjalan.")

def stop_script():
    global process
    if process and process.poll() is None:
        log_output("Menghentikan script...")
        print("Menghentikan script...")
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            log_output("Force kill script...")
            print("Force kill script...")
            process.kill()
    else:
        log_output("Script tidak sedang berjalan.")
        print("Script tidak sedang berjalan.")

def monitor_triggers():
    log_output("Memulai monitoring trigger start/stop...")
    print("Memulai monitoring trigger start/stop...")
    while True:
        if os.path.exists(TRIGGER_START):
            start_script()
            os.remove(TRIGGER_START)
            log_output("Trigger start dihapus.")
            print("Trigger start dihapus.")
        
        if os.path.exists(TRIGGER_STOP):
            stop_script()
            os.remove(TRIGGER_STOP)
            log_output("Trigger stop dihapus.")
            print("Trigger stop dihapus.")

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    try:
        monitor_triggers()
    except KeyboardInterrupt:
        print("\nMonitoring dihentikan.")
        log_output("Monitoring dihentikan.")
        stop_script()
