
from core.bot import Bot
from core.commands import Command
from abstracts.base_command import BaseCommand
from ai_temen_main import dapatkan_respon_gemini

class ResponAICmd(BaseCommand):
    def __init__(self, message: str):
        self.message = message
    
    async def execute(self, bot: Bot, cmd: Command):
        response = dapatkan_respon_gemini(self.message)
        # Format message with the correct zone chat format
        bot.write_message(f"%xt%zm%message%{bot.areaId}%{response}%zone%")
        
    def to_string(self):
        return f"{self.message}"
