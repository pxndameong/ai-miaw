from core.bot import Bot
from abstracts.base_command import BaseCommand
from core.commands import Command

class JoinHouseCmd(BaseCommand):
    
    def __init__(self, houseName: str, safeLeave: bool = True):
        self.houseName = houseName
        self.safeLeave = safeLeave
    
    async def execute(self, bot: Bot, cmd: Command):
        await bot.ensure_leave_from_combat()
        bot.is_joining_map = True
        msg = f"%xt%zm%house%1%{self.houseName}%"
        bot.write_message(msg)
        
        # Check response in handler
        if "Room join failed, destination room is full." in msg:
            print(f"Skipping house: {self.houseName} (Room join failed, destination room is full.)")
            return
        
    def to_string(self):
        return f"Goto house : {self.houseName}"
