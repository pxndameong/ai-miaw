from core.bot import Bot
from core.commands import Command
from abstracts.base_command import BaseCommand
from discord.ext.commands import Context

class ResponDiscordCmd(BaseCommand):
    def __init__(self, message: str):
        self.message = message  # Menyimpan message yang diterima

    async def execute(self, bot: Bot, cmd: Command, ctx: Context):
        # Impor miaw hanya di sini untuk menghindari circular import
        from respon_discord_main import miaw
        
        # Gunakan message dari self
        await miaw(ctx, pesan=self.message)  # Kirimkan pesan yang sudah diformat
        bot.write_message(f"%xt%zm%message%{bot.areaId}%{self.message}%zone%")
    
    def to_string(self):
        return f"{self.message}"
