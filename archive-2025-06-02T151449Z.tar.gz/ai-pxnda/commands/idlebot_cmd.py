from core.bot import Bot
from core.commands import Command
from abstracts.base_command import BaseCommand
from colorama import Fore
import asyncio

class IdleCmd(BaseCommand):

    def __init__(self, msg: str = ""):
        self.msg = msg

    async def execute(self, bot: Bot, cmd: Command):
        print(Fore.YELLOW + self.msg + Fore.RESET)
        
        # Indefinitely idle, just keep the bot alive and doing nothing
        while True:
            await asyncio.sleep(1)  # Keeps the bot alive without doing anything

    def to_string(self):
        return "IDLE Dulu"
