import discord
from discord.ext import commands

# Ganti dengan ID channel untuk log
LOG_CHANNEL_ID = 1370717345366016003  # <-- Ganti dengan channel ID log-mu

# Setup intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Buat bot instance
bot = commands.Bot(command_prefix="!", intents=intents)

# Fungsi logging pesan untuk 'say' dan 'guild'
async def discord_message(client: discord.Client, message: discord.Message, log_type: str):
    """Mencatat pesan user ke channel log Discord dan mengembalikan pesan log."""
    if message.author.bot:
        return

    username = message.author.nick if hasattr(message.author, 'nick') and message.author.nick else message.author.name
    isi_pesan = message.content
    pesan_log = f"{username} : {isi_pesan}"

    log_channel = client.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        if log_type == "say":
            await log_channel.send(f"[LOG SAY] {pesan_log}")
        elif log_type == "guild":
            await log_channel.send(f"[LOG GUILD] {pesan_log}")

    return pesan_log

# Event saat bot siap
@bot.event
async def on_ready():
    print(f"Bot sudah login sebagai {bot.user}")

# Event saat menerima pesan
@bot.event
async def on_message(message):
    # Variabel untuk menyimpan pesan log
    pesan_log_say = ""
    pesan_log_guild = ""

    # Mengecek jika pesan diawali dengan !s atau !g
    if message.content.startswith("!s"):
        teks = message.content[2:]  # Mengambil pesan setelah !s
        pesan_log_say = await discord_message(bot, message, "say")
        print(pesan_log_say)  # Menampilkan pesan log say

    elif message.content.startswith("!g"):
        teks = message.content[2:]  # Mengambil pesan setelah !g
        pesan_log_guild = await discord_message(bot, message, "guild")
        print(pesan_log_guild)  # Menampilkan pesan log guild

    await bot.process_commands(message)  # penting agar command tetap berjalan

# Jalankan bot
if __name__ == "__main__":
    TOKEN = "MTM0MTI2MjQwNTMzODAwNTU4NQ.G4fNTy.HVt99yoiiSC1gtmDkOaJ_kLQf3SIMjINk2VMFw"  # Ganti dengan token aslimu
    bot.run(TOKEN)
