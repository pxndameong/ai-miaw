from core.bot import Bot
from templates.hunt import hunt_item_cmds
import commands as cmd
import asyncio

# Initialize bot
b = Bot(
    cmdDelay=1000,
    autoRelogin=True,
    showLog=True, 
    showDebug=False,
    #emote=False,
    selamatdatang=True,
    #discordmessage=True,
    aipxnda=True,
    showChat=True)
b.set_login_info("pxndamiaw", "pandamiaw", "yorumi")

b.add_cmds([
        cmd.SleepCmd(500),
        #cmd.JoinHouseCmd("temen"),
        cmd.JoinHouseCmd("pxndameong"),    #pxndameong house
        cmd.SleepCmd(4000),
        #cmd.JumpCmd("R1", "Center"),
        cmd.WalkCmd(x=309, y=310),         #pxndameong house
        #cmd.WalkCmd(x=216, y=375),
        #cmd.SleepCmd(2000),
        #cmd.WalkCmd(x=335, y=300)
    ])

# Start bot
asyncio.run(b.start_bot())