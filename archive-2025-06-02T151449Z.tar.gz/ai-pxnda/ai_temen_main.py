import random
import time
import re
import requests
from unidecode import unidecode
from openai import OpenAI
from core.bot import Bot  # dipertahankan sesuai permintaan

# Setup API
#API_KEY = "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" #deepseek
API_KEY = "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" #Arqi UwU
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=API_KEY
)

# Hilangkan aksen
def bersihkan_aksen(text):
    return unidecode(text)

# Ganti keyword sensitif
def ganti_kata_kunci(text):
    keywords = ["china", "deepseek", "liang wenfeng", "gemini", "openai", "chatgpt", "OpenAI","arli","Arli"]
    for word in keywords:
        if word.lower() in text.lower():
            return "Qib tidak memperbolehkanku membicarakan itu"
    return text

# Bersihkan tag khusus
def bersihkan_tanda(text):
    return text.replace("/boxed", "")

# Ambil kata-kata random
def baca_kata_kata(file_path="/home/container/ai-pxnda/katakata/katakatapxnda.txt"):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
            return random.choice(lines) if lines else "Belum siap bikin kata-kata."
    except:
        return "Aduh malu"

# Ambil class berdasarkan keyword
def baca_classes(file_path="/home/container/ai-pxnda/katakata/classes.txt", keyword=" "):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        blocks = re.split(r"\n\n+", content.strip())
        for block in blocks:
            lines = block.split("\n")
            class_name_match = re.match(r"\[(.+?)\]", lines[0])
            if not class_name_match:
                continue

            class_name = class_name_match.group(1)
            ench, combo = [], []
            for line in lines[1:]:
                if line.startswith("ench_") and ":" in line:
                    ench.append(line.split(":", 1)[1].strip())
                elif line.startswith("combo_") and ":" in line:
                    combo.append(line.split(":", 1)[1].strip())

            if re.search(r"keywords:\s*(.+)", block, re.IGNORECASE):
                keywords_line = re.search(r"keywords:\s*(.+)", block, re.IGNORECASE).group(1)
                if keyword.lower() in keywords_line.lower():
                    ench_text = random.choice(ench) if ench else ""
                    combo_text = random.choice(combo) if combo else ""
                    return " -- ".join([class_name, ench_text, combo_text]).strip(" --")

        return "Ouch, belum ada dari Qib"
    except Exception as e:
        return f"Error membaca file: {e}"

# Fungsi utama respon
def dapatkan_respon_gemini(prompt):
    MAX_RETRY = 3
    TIMEOUT = 30

    # Prompt khusus
    if any(k in prompt.lower() for k in ["kata kata", "katakata", "kata-kata", "kata2"]):
        time.sleep(1)
        return baca_kata_kata()

    if "class " in prompt.lower():
        keyword = prompt.lower().replace("class ", "").strip()
        time.sleep(1)
        return baca_classes(keyword=keyword)

    if "siapa kamu" in prompt.lower() or "siapa asalmu" in prompt.lower() or "siapa penciptamu" in prompt.lower():
        time.sleep(1)
        return "Aku dibuat oleh si Qib."

    if "siapa aku" in prompt.lower() or "siapa namaku" in prompt.lower():
        time.sleep(1)
        return f"Kata Qib, namamu {(Bot.sender).title()}"

    if "qib" in prompt.lower():
        time.sleep(1)
        return "Qib tu yang buat aku! Hummm"

    # Prompt umum
    final_prompt = f"(Jadi wanita, jawab singkat (<150 char) dalam 1 baris dengan santai kepada {Bot.sender}, tanpa kutip/emote): {prompt}"

    for attempt in range(1, MAX_RETRY + 1):
        try:
            completion = client.chat.completions.create(
                model="deepseek/deepseek-chat-v3-0324:free",
                #model="deepseek/deepseek-v3-base:free",
                messages=[{"role": "user", "content": final_prompt}],
                timeout=TIMEOUT
            )

            if completion and completion.choices:
                text = completion.choices[0].message.content.strip()
                text = ganti_kata_kunci(text)
                text = bersihkan_aksen(text)
                text = bersihkan_tanda(text)
                return text[:150]

            return f"Humm, ngantuk capek. Habis jam tujuh pagi aja ya {Bot.sender}, aku baru mau jawab."

        except (requests.exceptions.Timeout, Exception) as e:
            print(f"[Retry {attempt}] Timeout atau error API: {e}")
            if attempt < MAX_RETRY:
                time.sleep(2)
            else:
                return "Maaf, lagi capek bentar"

# Interaksi CLI
def main():
    while True:
        user_input = input("Saya: ")
        if "hi-miaw" in user_input.lower():
            prompt = user_input.lower().replace("hi-miaw", "").strip()
            if prompt:
                response = dapatkan_respon_gemini(prompt)
                print(f"Hi, {response}")

if __name__ == "__main__":
    main()
