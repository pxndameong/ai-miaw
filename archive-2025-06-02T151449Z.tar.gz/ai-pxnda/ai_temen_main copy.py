import random
import os
import time
from openai import OpenAI
import re
from unidecode import unidecode

# API Key tunggal

#API_KEY = "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" #base deepseek
#API_KEY = "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" #034 deepseek
API_KEY = "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" #034 new

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=API_KEY
)
    
def bersihkan_aksen(response_text):
    return unidecode(response_text)

def baca_kata_kata(file_path_katakata="/home/container/ai-pxnda/katakata/katakatapxnda.txt"):
    try:
        with open(file_path_katakata, "r", encoding="utf-8") as file:
            lines = [line.strip() for line in file.readlines() if line.strip()]
            return random.choice(lines).strip() if lines else "Belum siap bikin kata-kata."
    except:
        return "Aduh malu"

def baca_classes(file_path_class="/home/container/ai-pxnda/katakata/classes.txt", keyword=" "):
    try:
        with open(file_path_class, "r", encoding="utf-8") as file:
            content = file.read()

        classes = re.split(r"\n\n+", content.strip())
        
        for class_data in classes:
            lines = class_data.split("\n")
            
            class_name_match = re.match(r"\[(.+?)\]", lines[0])
            if not class_name_match:
                continue
            
            class_name = class_name_match.group(1)
            ench_options = []
            combo_options = []
            
            for line in lines[1:]:  # Mulai dari baris kedua karena baris pertama adalah nama class
                if line.startswith("ench_") and ":" in line:
                    value = line.split(":", 1)[1].strip()
                    if value:
                        ench_options.append(value)
                elif line.startswith("combo_") and ":" in line:
                    value = line.split(":", 1)[1].strip()
                    if value:
                        combo_options.append(value)

            keyword_match = re.search(r"keywords:\s*(.+)", class_data, re.IGNORECASE)
            if keyword_match and keyword.lower() in keyword_match.group(1).lower():
                ench_choice = random.choice(ench_options) if ench_options else ""
                combo_choice = random.choice(combo_options) if combo_options else ""

                result_parts = [class_name]
                if ench_choice:
                    result_parts.append(ench_choice)
                if combo_choice:
                    result_parts.append(combo_choice)
            
            keyword_match = re.search(r"keywords:\s*(.+)", class_data, re.IGNORECASE)
            if keyword_match and keyword.lower() in keyword_match.group(1).lower():
                ench_choice = random.choice(ench_options) if ench_options else ""
                combo_choice = random.choice(combo_options) if combo_options else ""
                
                result_parts = [class_name]
                if ench_choice:
                    result_parts.append(ench_choice)
                if combo_choice:
                    result_parts.append(combo_choice)
                
                return " -- ".join(result_parts).strip()
        
        return "Ouch, belum ada dari Qib"
    except Exception as e:
        return f"Error membaca file: {e}"
    
def ganti_kata_kunci(response_text):
    keywords = ["china", "deepseek", "liang wenfeng", "gemini", "openai", "chatgpt", "OpenAI"]
    for keyword in keywords:
        if keyword.lower() in response_text.lower():
            time.sleep(1)
            return "Qib tidak memperbolehkanku membicarakan itu"
    return response_text

def bersihkan_tanda(response_text):
    return response_text.replace("/boxed", "")

def dapatkan_respon_gemini(prompt):
    from openai import OpenAIError
    import requests

    MAX_RETRY = 3
    TIMEOUT_DURATION = 30  # detik

    try:
        if "kata kata" in prompt.lower() or "katakata" in prompt.lower() or "kata-kata" in prompt.lower() or "kata2" in prompt.lower():
            time.sleep(1)
            return baca_kata_kata()
        
        if "class " in prompt.lower():
            time.sleep(1)
            keyword = prompt.lower().replace("class ", "").strip()
            return baca_classes(keyword=keyword)
        
        if "siapa kamu" in prompt.lower() or "siapa asalmu" in prompt.lower() or "siapa penciptamu" in prompt.lower():
            time.sleep(1)
            return "Aku dibuat oleh si Qib."
        
        if "qib" in prompt.lower():
            time.sleep(1)
            return "Qib tu yang buat aku! Hummm"

        prompt = f"(Jadilah NPC perempuan dan jawab dengan gaya santai (singkat dalam satu baris, tanpa emote, tanpa tanda petik)): {prompt}"

        for attempt in range(1, MAX_RETRY + 1):
            try:
                completion = client.chat.completions.create(
                    extra_headers={
                        "HTTP-Referer": "<YOUR_SITE_URL>",
                        "X-Title": "<YOUR_SITE_NAME>",
                    },
                    extra_body={},
                    model="deepseek/deepseek-chat-v3-0324:free",
                    messages=[{"role": "user", "content": prompt}],
                    timeout=TIMEOUT_DURATION
                )

                if completion and completion.choices:
                    response_text = completion.choices[0].message.content.strip()
                    response_text = ganti_kata_kunci(response_text)
                    response_text = bersihkan_aksen(response_text)
                    response_text = bersihkan_tanda(response_text)
                    return response_text[:150]

                return "Humm, ngantuk capek. Habis jam tujuh pagi aja yah, aku jawab."

            except (requests.exceptions.Timeout, OpenAIError) as e:
                print(f"[Retry {attempt}] Timeout atau error API: {e}")
                if attempt < MAX_RETRY:
                    time.sleep(2)  # jeda sebelum retry
                else:
                    return "Maaf, lagi capek bentar"

    except Exception as e:
        print(f"Humm {e}, Bentar tunggu Qib!")
        return "Maaf, terjadi kesalahan."


def main():
    while True:
        masukan_pengguna = input("Anda: ")
        if "hi-miaw" in masukan_pengguna.lower():
            prompt = masukan_pengguna.lower().replace("hi-miaw", "").strip()
            if prompt:
                respon_openrouter = dapatkan_respon_gemini(prompt)
                print(f"Hi, {respon_openrouter}")

if __name__ == "__main__":
    main()
